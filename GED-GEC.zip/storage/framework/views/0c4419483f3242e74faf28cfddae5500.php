<?php $__env->startSection('title','Profil'); ?>
<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/Insription.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="center-form">
    <div class="container-ins">
        <header class="head">Modification de profil</header>
        <form action="<?php echo e(route('user.user.update',['user'=>$user])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form first">
                <div class="details personal">
                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger" style="background: #dc354691;"><?php echo e(Session::get('fail')); ?></div>
                    <?php endif; ?>
                    <div class="fields">
                        <div class="input-field">
                            <label for="nom">Nom</label>
                            <input type="text" placeholder=" Entrez votre nom" value="<?php echo e(old('nom') ? old('nom') : $user->nom); ?>" name="nom">
                            <span style="color: #dc354691;"><?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="input-field">
                            <label for="prenom">Prénom</label>
                            <input type="text" placeholder=" Entrez votre prénom" value="<?php echo e(old('prenom') ? old('prenom') : $user->prenom); ?>" name="prenom">
                            <span style="color: #dc354691;"><?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="input-field">
                            <label for="email">Email</label>
                            <input type="email"  value="<?php echo e($user->email); ?>" <?php if(true): echo 'readonly'; endif; ?> name="email">
                            <span style="color: #dc354691;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="input-field">
                            <label for="motdepasse">Mot de passe</label>
                            <input type="password" placeholder=" Entrez votre mot de passe" value="<?php echo e(old('motdepasse')); ?>" name="motdepasse">
                            <span style="color: #dc354691;"><?php $__errorArgs = ['motdepasse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="input-field">
                            <label for="cpwd">Confirmer le mot de passe</label>
                            <input type="password" placeholder=" Confirmez votre mot de passe" value="<?php echo e(old('cpwd')); ?>" name="cpwd">
                            <span style="color: #dc354691;"><?php $__errorArgs = ['cpwd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="input-field">
                            <label for="">Date de naissance</label>
                            <input type="date" name="dateNaissance" id="" placeholder="Entrez votre date de naissance" value="<?php echo e(old('dateNaissance') ? old('dateNaissance') : $user->dateNaissance); ?>" >
                            <span style="color: #dc354691;"><?php $__errorArgs = ['dateNaissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <input type="hidden" name="cree_a" value="datetime">
                        <div class="input-field">
                            <label for="villeNaissance">Ville de naissance</label>
                            <input type="text" placeholder=" Entrez votre ville de naissance" value="<?php echo e(old('villeNaissance') ? old('villeNaissance') : $user->villeNaissance); ?>" name="villeNaissance">
                            <span style="color: #dc354691;"><?php $__errorArgs = ['villeNaissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                         </div>
                        <div class="input-field">
                            <label for="service">Service</label>
                             <select name="service_id" id="service">
                                   <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->idSer); ?>"><?php echo e($service->nomSer); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                            <span style="color: #dc354691;"><?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                         </div>
                    </div>
                    <button class="inscription" type="submit">
                        <span class="btnText">Valider</span>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/edit.blade.php ENDPATH**/ ?>