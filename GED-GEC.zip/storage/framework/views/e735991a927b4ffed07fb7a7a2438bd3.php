

<?php $__env->startSection('title', $mail->exists ? 'Modifier un mail' : 'Créer un mail'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Connexion.css')); ?>">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Symbols+Sharp">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="center-form">
   <div class="container-log">
    <h1 class="my-3"><?php echo $__env->yieldContent('title'); ?></h1>
    <form action="<?php echo e(route($mail->exists ? 'user.mail.update' : 'user.mail.store', ['mail' => $mail])); ?>" method="post"
        class="v-stack gap-2" enctype="multipart/form-data">
        <?php echo method_field($mail->exists ? 'put' : 'post'); ?>
        <?php echo csrf_field(); ?>

        <div class="form first">
            <div class="details personal">
                <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger" style="background: #dc354691;"><?php echo e(Session::get('fail')); ?></div>
                <?php endif; ?>
                <div class="fields">
                    <div class="input-field">
                        <label for="nomMail">Nom </label>
                        <input type="text" placeholder="Nom du mail"
                            value="<?php echo e(old('nomMail') ? old('nomMail') : $mail->nomMail); ?>" name="nomMail">
                        <span class="text-danger" style="color: red;">
                            <?php $__errorArgs = ['nomMail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                    <?php
                        $route = request()
                            ->route()
                            ->getName();
                    ?>


                    <div class="input-field">
                        <label for="document">Document</label>
                        <input type="file" name="document" id="document">
                        <span class="text-danger" style="color: red;">
                            <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>

                    </div>


                    <div class="input-field">
                        <label for="service">Service</label>
                        <select name="service_id" id="service">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service->idSer); ?>"><?php echo e($service->nomSer); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger" style="color: red;">
                            <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                </div>
                
                <button class="inscription px-5" type="submit">
                    <?php if($mail->exists): ?>
                        <span class="btnText">Modifier</span>
                    <?php else: ?>
                        <span class="btnText">Créer</span>
                    <?php endif; ?>
                </button>
            </div>



        </div>
    </form>
   </div>
</div>

   


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/mail/form.blade.php ENDPATH**/ ?>