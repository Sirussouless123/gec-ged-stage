<?php $__env->startSection('title','Départements'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid plr_30 body_white_bg pt_30">
    <div class="row justify-content-center">
        
        <div class="col-lg-12">
            <div class="white_box QA_section">
                <div class="white_box_tittle list_header">
                    <h4>Liste des départements</h4>
                    <div class="box_right d-flex lms_block">
                        <a class="btn_1 mb-2 btn-lg email-gradient gradient-9-hover email__btn waves-effect" href="<?php echo e(route('admin.department.create')); ?>"><i
                            class="icon-pencil"></i>Ajout</a>
                    </div>
                </div>
                <div class="QA_table ">
                    <?php if(Session::has("success")): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert"">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                    <table class="table lms_table_active">
                        <thead>
                            <tr>
                               
                                
                                <th scope="col">N°</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Modifier</th>
                                <th scope="col">Supprimer</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               
                              
                                <td>
                                    <div class="d-flex align-items-center">
                                       
                                        <div class="flex-grow-1 ms-3">
                                            <p><?php echo e($department->idDep); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p><?php echo e($department->nomDep); ?></p>
                                </td>
                                <td>
                                   <a href="<?php echo e(route('admin.department.edit',['department'=>$department])); ?>" class="btn btn-dark text-white">Modifier</a>
                                </td>
                                <td>
                                   <form action="<?php echo e(route('admin.department.destroy',['department'=>$department])); ?>" method="post">
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">
                                        Supprimer
                                    </button>
                                   </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo e($departments->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/department/index.blade.php ENDPATH**/ ?>