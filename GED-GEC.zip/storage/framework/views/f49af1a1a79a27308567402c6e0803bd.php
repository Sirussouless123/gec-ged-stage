<div class="position-relative" x-data={menusearch:false}>                                         
   <input type="text" placeholder="Rechercher ici " @click="menusearch = !menusearch " @click.away="menusearch=false" wire:model="search" >
   <?php if(strlen($search) > 0): ?>
                   
   <div class="position-absolute w-100 search-style " style="z-index: 100" x-show="menusearch" >
       <?php if(count($results) > 0): ?>
             <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <p class="text-md-center fs-5">
                   <a href="<?php echo e(route('user.mail.search',['mail'=>$result])); ?>"><?php echo e($result->nomMail); ?></a>
                 </p>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php else: ?>
             <p>Aucune correspondance</p>
       <?php endif; ?>
   </div>
   <?php endif; ?>
</div><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/livewire/search.blade.php ENDPATH**/ ?>