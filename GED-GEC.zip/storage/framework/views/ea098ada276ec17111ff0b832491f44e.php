<?php $__env->startSection('title', 'Utilisateurs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center">

            <div class="col-lg-12">
                <div class="white_box QA_section">
                    <div class="white_box_tittle list_header">
                        <h4>Liste des utilisateurs </h4>
                        <div class="box_right d-flex lms_block">
                            <a class="btn_1 mb-2 btn-lg email-gradient gradient-9-hover email__btn waves-effect"
                                href="<?php echo e(route('admin.user.create')); ?>"><i class="icon-pencil"></i>Ajout</a>
                        </div>
                    </div>
                    <div class="QA_table ">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert"">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <table class="table lms_table_active">
                            <thead>
                                <tr>
                                    <th scope="col">N°</th>
                                    <th scope="col">Nom</th>
                                    <th scope="col">Prénom</th>
                                    <th scope="col">Département</th>
                                    <th scope="col">Service</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $nomSer = DB::table('users')
                                    ->join('services', 'services.idSer', '=', 'users.service_id')
                                    ->where('users.id', $user->id)
                                    ->select('services.nomSer')
                                    ->first();
                                    $nomDep = DB::table('departments')
                                    ->join('services', 'services.department_id', '=', 'departments.idDep')
                                    ->join('users','users.service_id','=','services.idSer')
                                    ->where('users.id', $user->id)
                                    ->select('departments.nomDep')
                                    ->first();  
                            ?>
                                    <tr>


                                        <td>
                                            <div class="d-flex align-items-center">

                                                <div class="flex-grow-1 ms-3">
                                                    <p><?php echo e($user->id); ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p><?php echo e($user->nom); ?></p>
                                        </td>
                                        <td>
                                            <?php echo e($user->prenom); ?>

                                        </td>
                                        <td>
                                            <?php echo e($nomDep->nomDep); ?>

                                        </td>
                                        <td>
                                            <?php echo e($nomSer->nomSer); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php echo e($users->links()); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/user/index.blade.php ENDPATH**/ ?>