<?php $__env->startSection('title',"Home"); ?>
 
<?php $__env->startSection('content'); ?>
<div class="container-fluid plr_30 body_white_bg pt_30">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="single_element">
                <div class="quick_activity">
                    <div class="row">
                        <div class="col-12">
                            <div class="quick_activity_wrap">
                                <div class="single_quick_activity">
                                    <h4>Total Document</h4>
                                    <h3> <span class="counter"><?php echo e($document); ?></span> </h3>
                                   
                                </div>
                                <div class="single_quick_activity">
                                    <h4>Total Mail</h4>
                                    <h3><span class="counter"><?php echo e($mail); ?></span> </h3>
                                   
                                </div>
                                <div class="single_quick_activity">
                                    <h4>Total Department</h4>
                                    <h3><span class="counter"><?php echo e($department); ?></span> </h3>
                                   
                                </div>
                                <div class="single_quick_activity">
                                    <h4>Total Service</h4>
                                    <h3><span class="counter"><?php echo e($service); ?></span> </h3>
                                   
                                </div>
                                <div class="single_quick_activity">
                                    <h4>Total Category</h4>
                                    <h3><span class="counter"><?php echo e($category); ?></span> </h3>
                                   
                                </div>
                                <div class="single_quick_activity">
                                    <h4>Total User</h4>
                                    <h3><span class="counter"><?php echo e($user); ?></span> </h3>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
     
 
     
       
        
  

       
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/index.blade.php ENDPATH**/ ?>