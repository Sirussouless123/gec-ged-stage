<?php $__env->startSection('title', $service->exists ? 'Modifier un service' : 'Créer un service'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="white_box mb_30">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">

                            <div class="modal-content cs_modal">
                                <div class="modal-header">
                                    <h5 class="modal-title"><?php echo $__env->yieldContent('title'); ?></h5>
                                </div>
                                <div class="modal-body">
                                    <form
                                        action="<?php echo e(route($service->exists ? 'admin.service.update' : 'admin.service.store',['service'=>$service] )); ?>" method="post"  class="gap-2 v-stack">
                                        <?php echo method_field($service->exists ? 'put' : 'post'); ?>
            <?php echo csrf_field(); ?>
          
                                        <div class>
                                            <?php echo $__env->make('shared.input', ['type'=>'text','label'=>'Nom du service', 'name'=>'nomSer','value'=>$service->nomSer], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php echo $__env->make('shared.select',[ 'label'=>'Département', 'name'=>'department_id', 'options'=>$departments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <button class="btn btn-success mt-3">
                                                        <?php if($service->exists): ?>
                                                            Modifier
                                                        <?php else: ?> 
                                                            Créer
                                                         <?php endif; ?>
                                                </button>                                       
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/service/form.blade.php ENDPATH**/ ?>