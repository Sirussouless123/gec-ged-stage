

<?php $__env->startSection('title', 'Courriers importants'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/card.css')); ?>" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid my-3">


    <div class="row g-5">

        <?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
      
       
        <div class="  col-lg-4 col-md-6 ">
            <div class="card ">
              <div class="image-content">
                <span class="overlay"></span>
                <?php
                    $image ='text-3.png';
                    if ($mail->formatMail == 'pdf'){
                        $image = 'pdf-1.png';
                    }elseif($mail->formatMail == 'docx'){
                        $image = 'word-1.png';
                    }
                    elseif($mail->formatMail == 'xlsx'){
                        $image = 'excel-1.png';
                    }
                    elseif($mail->formatMail == 'csv'){
                        $image = 'csv-1.png';
                    }
                    elseif($mail->formatMail == 'xml'){
                        $image = 'xml-2.png';
                    }
                ?>
  
                <div class="card-image">
                  <img src="<?php echo e(asset('assets/img/'.$image)); ?>" alt="" class="card-img" />
                </div>
              </div>
              <div class="card-content">
                <h2 class="name">Mail</h2>          
                <p>Nom : <?php echo e($mail->nomMail); ?></p>     
                <div class="icone">
                    <a href="<?php echo e(route('user.mail.edit', ['mail' => $mail->idMail])); ?>"
                        style="text-decoration:none;color : white; " class='bx bxs-folder'>
                    </a>
                    <a href="<?php echo e(route('user.downloadingmail',['mail'=>$mail->idMail])); ?>" style="text-decoration:none;color : white; " class='bx bxs-download'>
                    </a>
                    <form action="<?php echo e(route('user.mail.destroy', ['mail' => $mail->idMail])); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class='bx bxs-trash' style=" background: none;
                        color: white;
                        border: none;
                        padding: 0;
                        font: inherit;
                        cursor: pointer;
                        outline: inherit; "> </button>

                    </form>
                </div>
              </div>
            </div>
          </div>
       
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/mail/importants.blade.php ENDPATH**/ ?>