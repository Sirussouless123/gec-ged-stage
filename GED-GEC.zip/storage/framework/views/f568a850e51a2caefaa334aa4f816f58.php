

<button wire:click="test"> Click </button><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/livewire/add-mail.blade.php ENDPATH**/ ?>