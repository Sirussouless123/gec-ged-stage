

<?php $__env->startSection('title', 'Informaions documents'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/boxicons-2.1.4/boxicons-2.1.4/css/boxicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/style1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/doc.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/subnav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/tab_css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/fontawesome-free-6.4.0-web/css/all.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="doc-content ">
       
        <nav class="navbar navbar-expand-lg bg-light  ">
            <div class="container-fluid ">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse py-3" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="btn btn-outline-primary text-md-center " aria-current="page"
                                href="<?php echo e(route('user.document.create', ['document' => $newDoc])); ?>">Ajouter
                                document</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle  text-md-start" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                                <i class="fa-solid fa-list fa-lg"></i>
                                Ranger par
                            </a>
                            <ul class="dropdown-menu ">
                                <li><a class="dropdown-item "
                                        href="<?php echo e(route('user.showFormat', ['format' => 'recents'])); ?>">Documents récents</a>
                                </li>
                                <li><a class="dropdown-item "
                                        href="<?php echo e(route('user.showFormat', ['format' => 'anciens'])); ?>">Documents anciens</a>
                                </li>
                                <li><a class="dropdown-item "
                                        href="<?php echo e(route('user.showFormat', ['format' => 'format'])); ?>">Par format </a></li>
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('user.showFormat', ['format' => 'service'])); ?>">Par service</a></li>
                            </ul>


                    </ul>
                    <div class="profile_info" style="z-index :200">
                        <img src="<?php echo e(asset('assets/img/client_img.png')); ?>" alt="#">
                        <div class="profile_info_iner">
                            <?php
                                $infos = DB::table('users')->where('id',session('loginId'))->first();
                            ?>
                            <p>Bienvenue utilisateur</p>
                            <h5><?php echo e($infos->nom); ?> <?php echo e($infos->prenom); ?></h5>
                            <div class="profile_info_details">
                                <a href="<?php echo e(route('user.user.edit',['user'=>$infos->id])); ?>">Mon profil <i class="ti-user"></i></a>
                                <a href="<?php echo e(route('logout')); ?>">Log Out <i class="ti-shift-left"></i></a>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </nav>
       
    </section>

    <section class="sidebar_content ">
        <div class="main_content_iner ">
            <div class="container-fluid plr_30 body_white_bg pt_30">
                <div class="row justify-content-center">
                    <div class="col-md-3">
                        
                        <div class="email-sidebar pt-3">
                            <h4>Menu</h4>
                            <?php
                                $route = request()
                                    ->route()
                                    ->getName();
                            ?>
                            <ul class="text-start">
                                <li class="<?php echo e(str_contains($route, 'document') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('user.document.index')); ?>"><i class="fas fa-inbox"></i> Documents
                                        (<?php echo e($nbDoc); ?>)</a></li>


                            </ul>
                            <ul class="text-start mb-3">
                                <li>
                                    <a dropdown-toggle href="<?php echo e(route('user.document.index')); ?>" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside"
                                        class="<?php echo e(str_contains($route, 'type') ? 'active' : ''); ?>"><i class="ti-user"></i>
                                        Types de documents (<?php echo e($nbType); ?>)</a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="dropdown-item"
                                                    href="<?php echo e(route('user.showType', ['type' => $type->type])); ?>"><?php echo e($type->type); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </li>
                            </ul>
                            <ul class="text-start py-3 ">
                                <li>
                                    <a dropdown-toggle href="<?php echo e(route('user.document.index')); ?>" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside"
                                        class="<?php echo e(str_contains($route, 'service') ? 'active' : ''); ?>"><i
                                            class="ti-user"></i>Services (<?php echo e($nbSer); ?>)</a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="dropdown-item"
                                                    href="<?php echo e(route('user.showService', ['service' => $service])); ?>"><?php echo e($service->nomSer); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </li>
                            </ul>


                        </div>
                    </div>
                    <div class="col-md-9 ">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="infos-tab" data-bs-toggle="tab"
                                    data-bs-target="#infos-tab-pane" type="button" role="tab"
                                    aria-controls="infos-tab-pane" aria-selected="true">Informations</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="actions-tab" data-bs-toggle="tab"
                                    data-bs-target="#actions-tab-pane" type="button" role="tab"
                                    aria-controls="actions-tab-pane" aria-selected="false">Actions</button>
                            </li>
                            <?php if($document->formatDoc == 'docx'): ?>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="convert-tab" data-bs-toggle="tab"
                                    data-bs-target="#convert-tab-pane" type="button" role="tab"
                                    aria-controls="convert-tab-pane" aria-selected="false">Convertir le fichier</button>
                            </li>
                            <?php endif; ?>
                          
                        </ul>
                        <style>
                           
                            .infos{
                                height: 1000px;
                                overflow : auto;
                            }
                            .desc-style{
                                border : 1px solid gray ;
                                width : 800px ;
                                height : 200px;
                                
                           overflow: auto;
                           text-align: justify;
                            padding-left: 5px;
                          
                            }
                        </style>
                        <?php
                           $nomSer = DB::table('documents')->join('services','services.idSer','=','documents.service_id')->where('documents.user_id',session('loginId'))->select('services.nomSer')->first();
                           $name = $document->nomDoc . '-version-' . $document->numeroVersion . '.' . $document->formatDoc;
                            $path = 'storage/doc_' . session('loginId');
                            $doc = new App\Models\Document();
                          
                        ?>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active infos" id="infos-tab-pane" role="tabpanel"
                                aria-labelledby="infos-tab" tabindex="0">
                                 <h4 class="text-center"><?php echo e($document->nomDoc.'.'.$document->formatDoc); ?></h4>
                                 <div class="d-flex gap-1 gy-2 flex-column v-stack mt-2">
                                   <h6>Nom du document : <?php echo e($document->nomDoc); ?></h6>
                                   <h6>Format du document : <?php echo e($document->formatDoc); ?></h6>
                                   <h6>Date d'ajout du document : <?php echo e($document->dateVersion); ?></h6>
                                   <h6>Date de dernière modification : <?php echo e($document->updated_at); ?></h6>
                                   <h6>Version du document : <?php echo e($document->numeroVersion); ?></h6>
                                   <h6>Service : <?php echo e($nomSer->nomSer); ?></h6>
                                   <h6>Type du document : <?php echo e($document->type); ?></h6>
                                   <h6>Taille : <?php echo e(round(($document->taille)/1000000,2)); ?> Mb</p> 
                                </div>              
                                <div class=" gy-2 flex-column d-none d-xl-flex">
                                    <h5 class="">Description</h5>   
                                    <p class="desc-style pt-1 text-break">
                                         <?php echo e($document->description); ?>

                                        </p> 
                                </div>              
                            </div>
                            <div class="tab-pane fade show active convert" id="convert-tab-pane" role="tabpanel"
                            aria-labelledby="convert-tab" tabindex="0">
                             <h4 class="text-center">Word en Pdf</h4>
                             <div class="d-flex gap-1 gy-2 flex-column v-stack mt-2 justify-content-center">
                                 <form action="<?php echo e(route('user.document.convert')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Fichier word</label>
                                    <input type="file"  id="hiddenfile" style="visibility:hidden;" />
                                    <input  class="form-control" type="hidden" name="text1" size="50" value="<?php echo e($doc->getPathFile($document)); ?>" />
                                    <input  class="form-control" type="hidden" name="text2" size="50" value="<?php echo e($doc->getPath($document)['path']); ?>" />
                                    <input  class="form-control" type="hidden" name="text3" size="50" value="<?php echo e($doc->getPath($document)['name']); ?>" />
                                  
  <button class="btn btn-outline-primary" type="submit" value="Browse..." onclick="document.getElementById('hiddenfile').click.getFileName();" name="submit" >Continuer</button>
                                  
                                </div>
                                </form>
        
                            </div>              
                               
                        </div>
                            <div class="tab-pane fade" id="actions-tab-pane" role="tabpanel"
                                aria-labelledby="actions-tab" tabindex="0">
                                <div class="d-flex gap-1 gy-2 flex-column v-stack mt-2">
                                   
                                    <div class="d-flex gap-2">
                                       <h6>Modifier document : </h6>
                                        <a href="<?php echo e(route('user.document.edit', ['document' => $document->idDoc])); ?>"
                                        style="text-decoration:none;color : black; " class='bx bxs-folder mt-1'>
                                        </a>
                                    </div>
                                    <div class="d-flex gap-2">
                                       <h6>Supprimer document : </h6>
                                       <form action="<?php echo e(route('user.document.destroy', ['document' => $document->idDoc])); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class='bx bxs-trash'
                                            style=" background: none;color: black;border: none; padding: 0;font: inherit; cursor: pointer; outline: inherit; "
                                            class="mb-5">
                                        </button>
                                    </form>
                                    </div>
                                    <div class="d-flex gap-2">
                                       <h6>Télécharger document : </h6>
                                       <a href="<?php echo e(route('user.downloading', ['document' => $document->idDoc])); ?>"
                                        style="text-decoration:none;color : black; " class='bx bxs-download mt-1'>
                                    </a>
                                    </div>
                                    <?php if($document->formatDoc == 'pdf'): ?>
                                    <div class="d-flex gap-2">
                                        <h6>Ouvrir courrier : </h6>

                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop">
                                            Ouvrir
                                        </button>


                                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static"
                                            data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                            aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-fullscreen">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Fermer"></button>
                                                    </div>
                                                    <div class="modal-body">

                                                        <embed src="<?php echo e('/' . $path . '/' . $name); ?>" width="1366"
                                                            height="768" />
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Fermer</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                           <?php endif; ?>

                                 </div>      
                            </div>
                              
                        </div>




                    </div>
                </div>
            </div>

        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

   
    <script src="<?php echo e(asset('assets/user/js/tab_js.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/document/show.blade.php ENDPATH**/ ?>