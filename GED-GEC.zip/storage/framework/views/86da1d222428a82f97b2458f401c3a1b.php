<?php $__env->startSection('title', $department->exists ? 'Modifier un département' : 'Créer un département'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="white_box mb_30">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">

                            <div class="modal-content cs_modal">
                                <div class="modal-header">
                                    <h5 class="modal-title"><?php echo $__env->yieldContent('title'); ?></h5>
                                </div>
                                <div class="modal-body">
                                    <form
                                        action="<?php echo e(route($department->exists ? 'admin.department.update' : 'admin.department.store', ['department' => $department])); ?>"
                                        class="gap-2" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field($department->exists ? 'put' : 'post'); ?>

                                        <div class>
                                            <?php echo $__env->make('shared.input', [
                                                'type' => 'text',
                                                'label' => 'Nom du département',
                                                'name' => 'nomDep',
                                                'value' => $department->nomDep,
                                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                            <button class="btn btn-success ">
                                                <?php if($department->exists): ?>
                                                    Modifier
                                                <?php else: ?>
                                                    Créer
                                                <?php endif; ?>

                                            </button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/department/form.blade.php ENDPATH**/ ?>