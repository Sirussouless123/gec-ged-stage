<?php $__env->startSection('title', 'Créer un utilisateur'); ?>


<?php $__env->startSection('content'); ?>

<div class="container-fluid plr_30 body_white_bg pt_30">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="white_box mb_30">
                <div class="row justify-content-center ">
                    <div class="col-lg-6">

                        <div class="modal-content cs_modal">
                            <div class="modal-header">
                                <h5 class="modal-title"><?php echo $__env->yieldContent('title'); ?></h5>
                            </div>
                            <div class="modal-body">
                                <?php if(Session::has('fail')): ?>
                                <div class="alert alert-danger " ><?php echo e(Session::get('fail')); ?></div>
                            <?php endif; ?>
                                <form action="<?php echo e(route('admin.user.store')); ?>" method="POST" class="gap-2 v-stack">  
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <div class>
                                       <?php echo $__env->make('shared.input',['label'=>'Nom','placeholder'=>'Entrer le nom','name'=>'nom','type'=>'text','value'=> old('nom') ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                  
                                    <div class>

                                        <?php echo $__env->make('shared.input',['label'=>'Prénom','placeholder'=>'Entrer le prénom','name'=>'prenom','type'=>'text','value'=>old('prenom')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class>
                                        <label for="email">Email</label>
                                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?> "
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Entrer l' mail">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class>
                                        <?php echo $__env->make('shared.input',['label'=>'Date de naissance','name'=>'dateNaissance','type'=>'date','value'=>old('dateNaissance')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class>
                                        <?php echo $__env->make('shared.input',['label'=>'Ville de naissance','placeholder'=>'Entrer la ville de naissance','name'=>'villeNaissance','type'=>'text','value'=>old('villeNaissance')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class>
                                        <label for="service">Service</label>
                                        <select name="service_id" id="service" class="form-select">
                                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service->idSer); ?>"><?php echo e($service->nomSer); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                       </div>
                                    <div class="mt-2">
                                        <?php echo $__env->make('shared.input',['label'=>'Mot de passe','name'=>'motdepasse','type'=>'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                                    </div>
                                        
                                    <div class>
                                        <?php echo $__env->make('shared.input',['label'=>'Confirmer le mot de passe','name'=>'cpwd','type'=>'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                                    </div>
                                   
                                  
                                    
                                    
                                    <button class="btn_1 full_width text-center"> Valider</a>
                                   
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/user/form.blade.php ENDPATH**/ ?>