

<?php $__env->startSection('title', $document->exists ? 'Modifier un document' : 'Créer un document'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Insription.css')); ?>">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Symbols+Sharp">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="center-form ">
        <div class="container-ins">



            <h1 class="my-3"><?php echo $__env->yieldContent('title'); ?></h1>

            <form
                action="<?php echo e(route($document->exists ? 'user.document.update' : 'user.document.store', ['document' => $document])); ?>"
                method="post" class="v-stack gap-2" enctype="multipart/form-data">
                <?php echo method_field($document->exists ? 'put' : 'post'); ?>
                <?php echo csrf_field(); ?>

                <div class="form first">
                    <div class="details personal">
                        <?php if(Session::has('fail')): ?>
                            <div class="alert alert-danger" style="background: #dc354691;"><?php echo e(Session::get('fail')); ?></div>
                        <?php endif; ?>
                        <div class="fields">
                            <div class="input-field">
                                <label for="nomDoc">Nom </label>
                                <input type="text" placeholder="Nom du document"
                                    value="<?php echo e(old('nomDoc') ? old('nomDoc') : $document->nomDoc); ?>" name="nomDoc">
                                <span style="color: red;">
                                    <?php $__errorArgs = ['nomDoc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <?php
                                $route = request()
                                    ->route()
                                    ->getName();
                            ?>

                            <div class="input-field">
                                <label for="numeroVersion">Numéro version</label>
                                <input type="text" placeholder="Numéro de version du document"
                                    value="<?php echo e(old('numeroVersion') ? old('numeroVersion') : $document->numeroVersion); ?>"
                                    name="numeroVersion" <?php if($route == 'user.document.edit'): echo 'readonly'; endif; ?>>
                                <span style="color:red;">
                                    <?php $__errorArgs = ['numeroVersion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>


                            <div class="input-field">
                                <label for="document">Document</label>
                                <input type="file" name="document" id="document">
                                <span style="color:red;">
                                    <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="input-field">
                                <label for="description">Description(Optionnel)</label>
                                <textarea name="description" id="description"></textarea>
                                <span style="color:red;">
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="input-field">
                                <label for="type">Type du document</label>
                                <input type="text" placeholder=" Ex:Facture"
                                    value="<?php echo e(old('type') ? old('type') : $document->type); ?>" name="type">
                                <span style="color:red;">
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="input-field">
                                <label for="service">Service</label>
                                <select name="service_id" id="service">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->idSer); ?>"><?php echo e($service->nomSer); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span style="color:red;">
                                    <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                        </div>
                        <button class="inscription px-5" type="submit">
                            <?php if($document->exists): ?>
                                <span class="btnText">Modifier</span>
                            <?php else: ?>
                                <span class="btnText">Créer</span>
                            <?php endif; ?>
                        </button>
                    </div>



                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/document/form.blade.php ENDPATH**/ ?>