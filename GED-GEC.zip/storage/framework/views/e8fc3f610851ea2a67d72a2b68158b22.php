

<?php $__env->startSection('title', 'Profil'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/boxicons-2.1.4/boxicons-2.1.4/css/boxicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/style1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/fontawesome-free-6.4.0-web/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Insription.css')); ?>">


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="center-form">
        

        <div class="container d-flex justify-content-center">
            <div class="col-md-9 ">

                <div class="white_box ">
                    <div class="d-flex justify-content-between gap-2">
                        <div class="white_box_tittle list_header">
                            <h4>Informations de l'utilisateur</h4>
                        </div>
                        <div class="text-end">
                            <a href="<?php echo e(route('user.user.edit',['user'=>$user->id])); ?>" class="btn_1 mb-2 btn-lg email-gradient gradient-9-hover email__btn waves-effect" style="cursor: pointer;"> Modification</a>
                        </div>
                    </div>
                    <div class="QA_table ">

                        <table class="table " border="0">

                            <tbody>
                                <tr>

                                    <th class="row">Nom :</th>
                                    <td><?php echo e($user->nom); ?></td>

                                </tr>
                                <tr>

                                    <th class="row">Prénom :</th>
                                    <td><?php echo e($user->prenom); ?></td>

                                </tr>
                                <tr>

                                    <th class="row">Email(unique) :</th>
                                    <td><?php echo e($user->email); ?></td>

                                </tr>
                                <tr>

                                    <th class="row">Date de naissance :</th>
                                    <td><?php echo e($user->dateNaissance); ?></td>

                                </tr>
                                <tr>

                                    <th class="row">Ville de naissance :</th>
                                    <td><?php echo e($user->villeNaissance); ?></td>

                                </tr>
                                <tr>
                                    <?php
                                        $nomSer = DB::table('users')
                                            ->join('services', 'services.idSer', '=', 'users.service_id')
                                            ->where('users.id', session('loginId'))
                                            ->select('services.nomSer')
                                            ->first();
                                            $nomDep = DB::table('departments')
                                            ->join('services', 'services.department_id', '=', 'departments.idDep')
                                            ->join('users','users.service_id','=','services.idSer')
                                            ->where('users.id',session('loginId'))
                                            ->select('departments.nomDep')
                                            ->first();
                                          
                                    ?>
                                    <th class="row">Service :</th>
                                    <td><?php echo e($nomSer->nomSer); ?></td>
                                </tr>
                                <tr>
                                    <th class="row">Département :</th >
                                    <td><?php echo e($nomDep->nomDep); ?></td>  
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/profil.blade.php ENDPATH**/ ?>