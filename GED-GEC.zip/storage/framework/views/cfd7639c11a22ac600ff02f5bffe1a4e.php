<?php $__env->startSection('title', $category->exists ? 'Modifier une catégorie' : 'Créer une catégorie'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="white_box mb_30">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">

                            <div class="modal-content cs_modal">
                                <div class="modal-header">
                                    <h5 class="modal-title"><?php echo $__env->yieldContent('title'); ?></h5>
                                </div>
                                <div class="modal-body">
                                    <form
                                        action="<?php echo e(route($category->exists ? 'admin.category.update' : 'admin.category.store',['category'=>$category] )); ?>" method="post" class="gap-2 v-stack">
                                        <?php echo method_field($category->exists ? 'put' : 'post'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="user_id" value="0">
                                        <div class>
                                            <?php echo $__env->make('shared.input', ['type'=>'text','label'=>'Nom ', 'name'=>'nomCat','value'=>$category->nomCat], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <button class="btn btn-success">
                                                        <?php if($category->exists): ?>
                                                            Modifier
                                                        <?php else: ?> 
                                                            Créer
                                                         <?php endif; ?>
                                                </button>                                       
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/admin/category/form.blade.php ENDPATH**/ ?>