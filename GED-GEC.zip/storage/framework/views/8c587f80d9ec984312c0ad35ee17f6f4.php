<?php
    $class ??= null;
    $label ??= '';
    $name ??= strtolower($label);
    $options ??= [];
    $key ??= 'idDep';
    $value ??= 'nomDep';
    
?>
<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-group', $class]); ?>">
    <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-select">
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($option->$key); ?>"><?php echo e($option->$value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/shared/select.blade.php ENDPATH**/ ?>