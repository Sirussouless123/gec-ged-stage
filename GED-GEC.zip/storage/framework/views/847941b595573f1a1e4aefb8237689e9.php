<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Connexion.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Connexion'); ?>

<?php $__env->startSection('content'); ?>
    <div class="center-form">
        <div class="container-log">
            <header class="head">Connexion</header>
            <form class="connexion" action="<?php echo e(route('login')); ?>" method="post">
                <div class="form first">
                    <div class="details personal">
                        <?php if(Session::has('success')): ?>
                            <div style="background-color :#00ff00;" class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                        <?php endif; ?>
                        <?php if(Session::has('fail')): ?>
                            <div class="alert alert-danger " style="background: #dc354691;"><?php echo e(Session::get('fail')); ?></div>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="fields">
                            <div class="input-field">
                                <label for="">Email</label>
                                <input type="mail" placeholder=" Entrez votre email" value="<?php echo e(old('email')); ?>"
                                    name="email">
                                <span  style="color: #dc354691;">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="input-field">
                                <label for="">Mot de passe</label>
                                <input type="password" placeholder=" Entrez votre mot de passe" name="motdepasse">
                                <span style="color: #dc354691;">
                                    <?php $__errorArgs = ['motdepasse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                        </div>
                        <button class="inscription">
                            <span class="btnText">Valider</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/login.blade.php ENDPATH**/ ?>