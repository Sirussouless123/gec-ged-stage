<?php $__env->startSection('title', 'Documents'); ?>

<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/boxicons-2.1.4/boxicons-2.1.4/css/boxicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/style1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/doc.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/subnav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/fontawesome-free-6.4.0-web/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/fontawesome-free-6.4.0-web/css/regular.css')); ?>">
    <script src="<?php echo e(asset('assets/user/js/jquery-3.7.0.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 
    <section class="doc-content ">
        
        <nav class="navbar navbar-expand-lg bg-light  ">
            <div class="container-fluid ">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse py-3" id="navbarSupportedContent" >
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="btn btn-outline-primary text-md-center " aria-current="page" href="<?php echo e(route('user.document.create',['document'=>$newDoc])); ?>">Ajouter
                                document</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle  text-md-start" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                                <i class="fa-solid fa-list fa-lg"></i>
                                Ranger par
                            </a>
                            <ul class="dropdown-menu " >
                                <li><a class="dropdown-item " href="<?php echo e(route('user.showFormat',['format'=>'recents'])); ?>">Documents récents</a></li>
                                <li><a class="dropdown-item " href="<?php echo e(route('user.showFormat',['format'=>'anciens'])); ?>">Documents anciens</a></li>
                                <li><a class="dropdown-item " href="<?php echo e(route('user.showFormat',['format'=>'format'])); ?>">Par format </a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('user.showFormat',['format'=>'service'])); ?>">Par service</a></li>
                            </ul>
                           

                    </ul>
                    <?php 
                      $admin = DB::table('users')->where('id',session('loginId'))->select('users.statut')->first();
                    ?>
                    <?php if($admin->statut == 1): ?>
                    <div class="mx-2">
                        <a class="btn btn-outline-primary text-md-center" href="<?php echo e(route('admin.home')); ?>">
                              Dashboard
                        </a>
                    </div>
                    <?php endif; ?>
                    <div class="profile_info " style="z-index :200">
                        <img src="<?php echo e(asset('assets/img/client_img.png')); ?>" alt="#">
                        <div class="profile_info_iner">
                            <?php
                                $infos = DB::table('users')->where('id',session('loginId'))->first();
                            ?>
                            <p>Bienvenue utilisateur</p>
                            <h5><?php echo e($infos->nom); ?> <?php echo e($infos->prenom); ?></h5>
                            <div class="profile_info_details">
                                <a href="<?php echo e(route('user.profil',['user'=>$infos->id])); ?>">Mon profil <i class="fa-regular fa-user"></i></a>
                                <a href="<?php echo e(route('logout')); ?>">Déconnexion <i class="ti-shift-left"></i></a>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </nav>
        
    </section>

    <section class="sidebar_content ">
        <div class="main_content_iner ">
            <div class="container-fluid plr_30 body_white_bg pt_30">
                <div class="row justify-content-center">
                    <div class="col-md-3">
                        
                        <div class="email-sidebar pt-3">
                            <h4>Menu</h4>
                            <?php 
                                  $route = request()->route()->getName();
                            ?> 
                            <ul class="text-start">
                                <li class="<?php echo e(str_contains($route,'index') ?  'active' : ''); ?>"><a  href="<?php echo e(route('user.document.index')); ?>"><i class="fas fa-inbox"></i> Documents (<?php echo e($nbDoc); ?>)</a></li>


                            </ul>
                            <ul class="text-start mb-3">
                                <li class="<?php echo e(str_contains($route,'type') ?  'active' : ''); ?>">
                                    <a dropdown-toggle href="<?php echo e(route('user.document.index')); ?>"  data-bs-toggle="dropdown"
                                        aria-expanded="false" data-bs-auto-close="outside" ><i class="ti-user"></i> Types de documents (<?php echo e($nbType); ?>)</a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a style="color: black " class="dropdown-item" href="<?php echo e(route('user.showType',['type'=>$type->type])); ?>"><?php echo e($type->type); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                    </ul>
                                </li>
                            </ul>
                            <ul class="text-start py-3 ">
                                <li class="<?php echo e(str_contains($route,'service') ?  'active' : ''); ?>">
                                    <a dropdown-toggle href="<?php echo e(route('user.document.index')); ?>"  data-bs-toggle="dropdown"
                                        aria-expanded="false" data-bs-auto-close="outside" ><i class="ti-user"></i>Services (<?php echo e($nbSer); ?>)</a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a style="color: black " class="dropdown-item" href="<?php echo e(route('user.showService',['service'=>$service])); ?>"><?php echo e($service->nomSer); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                    </ul>
                                </li>
                            </ul>


                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="white_box QA_section">
                            <div class="white_box_tittle list_header">
                                <h4>Liste des documents</h4>
                                <div class="box_right d-flex lms_block">
                                    <div class="serach_field_2">
                                        <div class="search_inner">
                                           
                                                <div class="search_field">
                                                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('doc-search', [])->html();
} elseif ($_instance->childHasBeenRendered('ArJqhwl')) {
    $componentId = $_instance->getRenderedChildComponentId('ArJqhwl');
    $componentTag = $_instance->getRenderedChildComponentTagName('ArJqhwl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ArJqhwl');
} else {
    $response = \Livewire\Livewire::mount('doc-search', []);
    $html = $response->html();
    $_instance->logRenderedChild('ArJqhwl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                </div>
                                                <button type="submit"> <i class="ti-search"></i> </button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="QA_table ">

                                <table class="table lms_table_active">
                                   
                                    <tbody>

                                       
                                       
                      
                                        <tr>
                                           
                                             <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $image ='text-3.png';
                                        if ($document->formatDoc == 'pdf'){
                                            $image = 'pdf-1.png';
                                        }elseif($document->formatDoc == 'docx'){
                                            $image = 'word-1.png';
                                        }
                                        elseif($document->formatDoc == 'xlsx'){
                                            $image = 'excel-1.png';
                                        }
                                        elseif($document->formatDoc == 'csv'){
                                            $image = 'csv-1.png';
                                        }
                                        elseif($document->formatDoc == 'xml'){
                                            $image = 'xml-2.png';
                                        } elseif($document->formatDoc == 'zip' || $document->formatDoc == 'rar' ){
                                            $image = 'zip.jpg';
                                        }elseif ($document->formatDoc == 'pptx') {
                                            $image = 'pptx.jpg';
                                        }
                    
                                 
                                    ?>

                                            <td class="d-flex justify-content-center">
                                                <div class="card" style="max-width: 540px;">
                                                    <div class="row g-0">
                                                        <div class="col-md-4">
                                                            <img src="<?php echo e(asset('assets/img/'.$image)); ?>"
                                                                class="img-fluid rounded-start">
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="card-body">
                                                                <h5 class="card-title"><?php echo e($document->nomDoc.'.'.$document->formatDoc); ?></h5>
                                                                <p class="card-text"><small class="text-muted"><?php echo e($document->dateVersion); ?></small></p>
                                                                <p class="card-text"> <span class="badge bg-primary">Version <?php echo e($document->numeroVersion); ?></span></p>
                                                                <a href="<?php echo e(route('user.document.search',['document'=>$document])); ?>" style="text-decoration:none;color:white;" class="btn btn-primary text-center " >Plus d'infos</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($documents->links()); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
      
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('assets/user/js/side_js.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samsung\Documents\GED-GEC\resources\views/user/document/index.blade.php ENDPATH**/ ?>