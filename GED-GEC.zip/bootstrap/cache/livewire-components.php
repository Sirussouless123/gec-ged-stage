<?php return array (
  'doc-search' => 'App\\Http\\Livewire\\DocSearch',
  'favorite' => 'App\\Http\\Livewire\\Favorite',
  'report' => 'App\\Http\\Livewire\\Report',
  'search' => 'App\\Http\\Livewire\\Search',
);